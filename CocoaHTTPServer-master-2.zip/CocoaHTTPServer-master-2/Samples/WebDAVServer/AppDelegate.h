#import <Cocoa/Cocoa.h>

@class HTTPServer;

@interface AppDelegate : NSObject {
@private
  HTTPServer* _httpServer;
}
@end
