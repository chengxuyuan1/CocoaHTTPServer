
#import <Cocoa/Cocoa.h>

@class HTTPServer;

@interface AppDelegate : NSObject <NSApplicationDelegate> {
   	HTTPServer *httpServer;
}


@end
